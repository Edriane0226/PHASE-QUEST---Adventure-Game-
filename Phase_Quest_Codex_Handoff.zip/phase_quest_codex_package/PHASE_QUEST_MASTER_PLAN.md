# PHASE QUEST — Master redesign and implementation plan

**Status:** Codex handoff specification. **Goal:** implement in the existing project, not just produce mockups. **Visual authority:** `references/approved-hud-no-map.png` (HUD) and `references/approved-world-style.png` (simple environment). This document incorporates all confirmed changes from the design conversation.

## 1. Core vision
Phase Quest becomes a continuous, 2D isometric-style open-world puzzle adventure. The game retains **exactly three existing zones** as geographic regions (analogous to countries), with their existing levels as explorable cities/subregions inside each zone. Zone and Level Selection screens disappear; the zone/level identities and all their puzzle/progression data **do not disappear**. Travel across unlocked boundaries is seamless. Fog conceals areas and invisible collision barriers prevent entry until actual unlock prerequisites are met.

**Do not assume** a particular engine, the number of levels per zone, their names, unlock order, tile dimensions, coordinate system, or save schema. Determine these by inspecting the project.

## 2. Visual reference and asset conversion
- **Crystarise (YUKIUSAGI Games)** is an inspiration **only for world/environment presentation**: https://store.steampowered.com/app/1748750/Crystarise/ . Do not use its character designs, proportions, costumes, hairstyles, faces, or animations. Do not copy/extract proprietary assets.
- The **approved Phase Quest mockup** is the specific target for HUD placement, simplified green/brown terrain, low object density and overall scene readability. It takes priority over more detailed examples.
- Terrain: broad flat green surfaces, subtle or invisible tile grid, isometric diamond geometry, uneven stair-stepped boundaries, muted brown dirt sides, raised plateaus, readable elevations. Terrain should feel *simple and spacious*, not a detailed Minecraft voxel diorama.
- Trees: sparse, small groups of simple geometric green cuboid canopies and brown trunks. Rocks: gray block clusters. Cave: simple stacked gray blocks with dark opening. Water: flat muted blue with stepped shores. Other props: minimal tufts, yellow/white flowers, fallen log, small stone-ring campfire, glowing butterfly where those assets fit existing content.
- Preserve original Phase Quest player, NPC, enemy and costume designs. Update rendering scale, perspective alignment, outlines and animation compatibility without replacing identity. The lavender-haired mockup figure is a **visual example**, not permission to overwrite the existing player character.
- Replace or restyle all *in-use* environment assets: terrain tops/sides/corners/elevation, vegetation, trees, rocks, caves, water, shoreline, logs, campfires, interactive puzzle props, environmental VFX, HUD frames/icons, quest/tutorial panels, minimap graphics. Preserve identifiers, interactions and collisions. Prefer reusable sprites/tiles/models and consistent art production over screenshot cropping.
- Create original game-ready assets in the format and import pipeline the actual engine requires; record source and export formats, pivots, sorting layers, animation frames, scale, collision bounds and licenses. No invented hard-coded pixel/tile size until project inspection.

## 3. HUD — fixed layout and functionality
Use the approved **no-Map-button** screenshot. HUD is anchored to the display/safe area and must remain legible on landscape mobile aspect ratios. Maintain circular control proportions; do not stretch.

| Area | Elements | Behavior |
|---|---|---|
| Upper left | Diamond player portrait; **dynamic player name**; red HP; blue Warmth | Bind to actual player data. Name is **not** "Phase Quest" and is not an assumed fixed personal name. |
| Below upper left | Compact dark translucent active quest tracker | Show actual objectives and completion states. |
| Upper right | Guides, Pause, circular minimap | **No separate Map button.** Minimap tracks player and fog/discovery. |
| Near tutorial object | Cream contextual instruction bubble | Show contextually; dismiss/hide as appropriate after completion. |
| Lower left | Large translucent touch joystick | Drag-to-move, diagonal input, release-to-neutral; respect collision. |
| Lower center | **Five visual ability buttons**: two circles above; bottom row circle–central hexagon–circle | Match screenshot spacing/colors; use actual existing abilities and mappings; do not invent a fifth mechanic. Highlight selected ability. |
| Lower right | Run, Jump, Fire circular buttons | Touch accessible; Fire supports press-and-hold for Thermal tutorial; obey existing mechanics/cooldowns. |

**Remove from HUD:** inventory hotbar, currency counters, gamepad labels (LB/RB/LT/RT/Y/B etc.), Map button. **Remove from navigation:** Zone Selection and Level Selection screens. Do not delete inventory/currency **systems or saved data** just because their HUD is hidden.

The original tutorial example is `FIRST THAW - THERMAL`: “Select Thermal. Face nearby ice; hold Fire with a clear path.” Keep this as an example only; display project-authored quest text and real objective state. Do not hardcode example text across unrelated levels.

## 4. World hierarchy and map
- One continuous world coordinate system; three distinct existing zones as geographical regions, each containing its real levels as subregions/cities. Preserve actual IDs and associations.
- Existing levels have locations and connections appropriate to terrain and story. The player walks between unlocked areas without selection menus or unnecessary scene transitions. Streaming/chunk loading is allowed internally, but should be visually seamless.
- Do not simply concatenate level screenshots; integrate collision, elevations, camera bounds, NPCs, triggers, interactive puzzle entities and objective markers in a real navigable world.
- The minimap remains a circular overview of nearby discovered terrain and the player's position/orientation. A full-screen map is **not required**; do not add a Map HUD button. If the project already has a world-map feature, it may be accessible through an existing approved menu only if this does not violate the HUD reference.

## 5. Locked areas, fog and invisible barriers
**Separate progression permissions from visual discovery.** Recommended independent data:
- `progression`: locked / unlocked / in_progress / completed (level); locked / unlocked / completed (zone).
- `discovery`: undiscovered / discovered (or fog coverage per tile/chunk).

Expected progression:
1. Player starts in the currently allowed level, based on saved data or actual new-game start.
2. Next locked level/zone exists geographically but is obscured by fog and physically inaccessible.
3. Invisible collision/barrier blocks walking, running, jumping, ability movement and alternate routes into locked regions. Check all entry paths, including elevation and teleport mechanics if present.
4. Player completes the existing required puzzle/objective(s).
5. Existing authoritative progression logic determines which area unlocks. Do **not** assume sequential numeric ordering if project data differs.
6. On unlock, deactivate appropriate barrier(s), transition fog appropriately, and update minimap and quest guidance. Discovery fog may remain over still-unvisited portions of the unlocked area.
7. Save and reload retains unlocks, fog discovery and barrier behavior.

Fog states to represent: undiscovered; discovered-but-locked (partial preview if intended); unlocked-but-unexplored; explored. Fog should not reveal a locked area just because the player approaches it. Use soft semitransparent atmospheric mist at region transitions, not hard UI overlays or loading screens. Barrier itself should be invisible; optionally display a short contextual “Complete required objectives to enter” prompt, grounded in the actual prerequisite.

**Boundary test cases:** walking/running/jumping into a locked border; alternate paths; abilities crossing boundaries; moving from a completed level; reloading in an unlocked zone; returning to previous zones; world map/minimap visibility. A visually hidden barrier must not become a permanent trap after unlock.

## 6. Gameplay and technical preservation
Preserve the actual existing mechanics, especially Thermal, Pressure, Vacuum, Cryo; puzzle success/failure rules; quest objectives; HP and Warmth; character interactions; collision; rewards; progression; inventory/currency data; save/load. Keep project-authored names, character identities and level definitions. Do not invent replacement mechanics, quests, enemies, additional abilities, or zone counts.

Recommended **logical responsibilities**, adapted to actual architecture: world/region manager; terrain/elevation and collision; fog/discovery; player input/controller; ability manager; puzzle and quest state; progression/unlock service; HUD; minimap; save migration. These are **not mandatory class names**.

Use suitable orthographic/isometric rendering for the actual engine, correct sprite/object sorting by ground position/elevation, smooth player-follow camera and stable scale. Region-based loading/culling may be used for performance. Keep HUD fixed on screen. Optimize for target mobile hardware and test landscape safe areas.

## 7. Saves and migration
Inspect current save format before changing zone/level routing. Migrate existing zone + level identifiers to world positions, preserve all puzzle/quest/ability/inventory/currency progress, and restore current HP/Warmth, player name, selected ability, discovered fog and unlock state. Derive barrier activation from authoritative unlock data on load to avoid contradictory saved states. Add backward compatibility or explicit migration handling; do not silently wipe saves.

## 8. Implementation sequence
1. **Audit project:** engine, build, source/assets, scene graph, real zone and level names/count, progression dependencies, inputs, saves. Report facts vs unknowns.
2. **Safeguard:** version-control checkpoint/backup and dependency list before destructive asset/scene changes.
3. **Vertical slice:** one playable current-level area matching approved simplified world style and HUD, with working player controls, an existing puzzle, quest display, minimap and fog/barrier boundary.
4. **Asset pipeline:** reusable tiles/props/UI, consistent scale/pivots/animations, original characters retained.
5. **World migration:** place all three existing zones and all real levels into continuous geography, with paths and collision.
6. **Progression:** connect existing objective events to unlock state, barriers, fog, minimap and guidance.
7. **Persistence:** save migration and regression tests.
8. **Quality:** build, test mobile controls, scene transitions, performance, screenshot visual comparisons, fix regressions.

Do not stop after planning. Implement changes and honestly report what was and was not verified.

## 9. Definition of done / acceptance tests
- [ ] Original Phase Quest project modified; build launches.
- [ ] All **three** existing zones represented in one continuous world, with all actual levels in their correct zone.
- [ ] No Zone Selection or Level Selection screens in normal play.
- [ ] Terrain/assets visibly match simple approved reference, with original reusable assets, not a static screenshot.
- [ ] Existing player/NPC/enemy designs remain recognizable and not Crystarise-derived.
- [ ] HUD matches approved layout, dynamic player name, HP, Warmth, quest, Guides/Pause/minimap, joystick, five-button cluster, Run/Jump/Fire.
- [ ] No Map button, inventory/currency HUD or controller labels.
- [ ] Existing ability actions and puzzles still function.
- [ ] Fog covers locked/undiscovered areas and invisible barriers prevent early entry by all movement methods.
- [ ] Correct objective completion unlocks only eligible levels/zones; barriers clear and fog/minimap update.
- [ ] Save/load preserves player progress, identity, discovery, unlocks and underlying inventory/currency.
- [ ] Landscape touch UI works without overlap and performance is reasonable on target devices.
- [ ] Final report identifies changed files, tests, any unimplemented items and reference deviations.

## 10. Strict anti-drift rules
- Crystarise **environment only**; no Crystarise character inspiration.
- Approved mockup HUD, not Crystarise HUD.
- Keep simple low-detail environment; no overly detailed Minecraft voxels.
- Preserve three zones and their levels as **data and playable geography**; delete selection **screens only**.
- Locked areas need **both fog and collision**, and fog is not permission.
- Never re-add Map button, HUD inventory/currency or gamepad labels.
- Dynamic player **name**, not title, in portrait HUD.
- Do not fabricate a fifth ability from five UI slots.
- No unrelated game rewrite, new characters, new progression order or arbitrary zone names.
- Verify project code and references before resolving ambiguous details.
