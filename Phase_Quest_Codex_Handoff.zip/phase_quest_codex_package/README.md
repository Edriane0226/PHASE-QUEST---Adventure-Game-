# How to use this package

1. Extract this ZIP into the **root** of your existing Phase Quest project folder (where the game source/build files are). Do not replace existing game source files.
2. Keep `AGENTS.md` and `PHASE_QUEST_MASTER_PLAN.md` in that root. Keep the `references/` images alongside them.
3. Open Codex with the project folder as its workspace and ask: “Read AGENTS.md and PHASE_QUEST_MASTER_PLAN.md, inspect the project, then implement the redesign in phases. Start by reporting the actual engine, zone/level inventory, and asset pipeline. Do not invent missing details.”
4. Check the image references visually in Codex. They are visual mockups, not extracted sprite assets.

If the project already has an AGENTS.md or references folder, merge carefully rather than blindly overwrite existing instructions.
