# Phase Quest — Codex project instructions

Read `PHASE_QUEST_MASTER_PLAN.md` in full before editing. Treat it as the authoritative requirements document. Review `references/approved-hud-no-map.png` and `references/approved-world-style.png` visually if image inspection is supported. The reference screenshots are **visual targets, not usable sprite atlases**.

## Mission
Modify the **existing** Phase Quest project in this folder. Convert its existing three zones and their existing levels into one connected isometric-style explorable world, replacing environmental assets to match the approved simplified art direction, and implement the approved mobile HUD. Preserve original Phase Quest character designs, gameplay, puzzles, abilities, quest logic, and saves.

## Non-negotiables
- **Three zones remain** in gameplay data and world geography. Zones act like countries; levels act like cities/subregions. Remove *selection screens*, not zone/level systems.
- Locked zones/levels are concealed by fog **and** blocked by invisible collision. Unlock according to the project's real prerequisite rules; fog visibility and access permission are distinct.
- Art: Crystarise is a **world/environment-only inspiration**, never a character reference. Use original assets; do not extract or copy proprietary Crystarise content. Simplified, airy, low-detail isometric stepped green terrain with brown dirt sides, sparse cubic trees, rocks, water and caves; avoid hyper-detailed Minecraft textures.
- Preserve original Phase Quest player/NPC/enemy appearance, outfits, hairstyles, identity, and recognizable silhouettes. Adapt rendering/animation compatibility only as needed.
- HUD: top-left portrait, **dynamic player name** (NOT game title), HP, Warmth, quest tracker; top-right Guides, Pause, circular minimap; bottom-left touch joystick; bottom-center five-button ability cluster in approved arrangement; bottom-right Run, Jump, Fire; contextual tutorial bubble near relevant world objects.
- Remove the separate Map **button**, Zone Selection, Level Selection, inventory/currency HUD and controller labels. **Keep minimap**, and preserve underlying inventory/currency data and systems.
- Do not invent an extra ability to fill five visual slots: inspect existing mappings and retain their real behavior.
- Do not turn the mockup into a flat background. Implement actual reusable game assets, collision, animation, fog, puzzles and interactive objects.
- No unrelated mechanics, menus, characters, or game redesigns.

## Workflow
1. Inspect engine, build scripts, scene hierarchy, art pipeline, zone/level definitions, progression, save data, and input system. Do not assume Unity/Godot/other engine.
2. Create a brief inventory and implementation checklist, including actual zone/level names and prerequisites. Identify unclear details instead of guessing.
3. Safeguard the existing project (version control/backup), then implement an end-to-end playable vertical slice matching the approved HUD and art direction.
4. Replace assets and migrate remaining zones/levels, with correct collision, fog, barriers, unlock events, map display and save migration.
5. Run builds/tests where supported. Report exactly what changed, what was tested, remaining limitations and any reference fidelity gaps. Never claim unperformed tests.

## Reference precedence
1. Explicit user requirements and the detailed master plan.
2. Approved HUD reference for **UI geometry and placement**.
3. Approved simplified world reference for **density and terrain simplicity**.
4. Crystarise for **environmental mood/world art only**.
5. Existing Phase Quest code/data for character identity and actual mechanics/progression.

If requirements conflict, preserve gameplay and original character identity, do not silently make new design decisions, and explain the conflict.
